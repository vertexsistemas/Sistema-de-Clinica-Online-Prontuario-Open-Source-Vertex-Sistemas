<?php foreach($dadospaciente as $dp);?>
<html>
    <head>
        <meta charset="UTF-8">
        
            <title>On Clinica | O seu consultório online de maneira rápida e segura!</title>


            <link rel="stylesheet" href="<?php echo base_url('public/_css/estilos.css');?>" type="text/css" media="screen" />
            <link rel="stylesheet" href="<?php echo base_url('public/_css/bootstrap.css');?>" type="text/css" media="screen" />
            <script src="<?php echo base_url('public/_js/jquery.js');?>"></script>
            <script src="<?php echo base_url('public/ckeditor/ckeditor.js');?>"></script>
            <script src="<?php echo base_url('public/_js/bootstrap.min.js');?>"></script>
            <script src="http://getbootstrap.com/2.3.2/assets/js/holder/holder.js"></script>
            
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/reset.css');?>' />
            <link rel='stylesheet' type='text/css' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/start/jquery-ui.css' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/jquery.weekcalendar.css');?>' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/demo.css');?>' />

            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js'></script>
            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js'></script>

            <script type='text/javascript' src='<?php echo base_url('public/_js/cep.js');?>'></script>

      
    </head>
    
    <body>
        

            
            <ul class="nav nav-tabs">
              <li><a href="<?php echo base_url('index.php/clinica/editarPaciente/'.$dp->idpacientes);?>">Dados pessoais</a></li>
              <li><a href="<?php echo base_url('index.php/clinica/prontuario/'.$dp->idpacientes);?>">Prontuários</a></li>
              <li class="active"><a href="<?php echo base_url('index.php/clinica/minhasimagens/'.$dp->idpacientes);?>">Minhas imagens</a></li> 
            </ul>
        
        
        <div style="margin: 10px;">
            <table width="100%">
                <tr>
                    <td>
                        <?php echo str_pad($dp->idpacientes, 10, "0", STR_PAD_LEFT);?>
                    </td>
                    <td>
                        <?php echo $dp->nomepacientes;?>
                    </td>
                    <td>
                        <?php echo date('d/m/Y',strtotime($dp->datanasc));?>
                    </td> 
                    <td>
                        <?php $data = explode('-',$dp->datanasc); echo date('Y') - $data[0]." Anos" ?>
                    </td>                     
                </tr>
            </table>
        </div>
        
        <table width="100%">
            <tr>
                <td>
                    <div style="font-size: 25px; font-weight: bold; margin: 10px;">
                       Imagens de exames 
                    </div>                    
                </td> 

            </tr>
        </table>


        
        <div style="margin: 10px;">
            
            <table width="100%">
                <?php if(is_array($imagensdopaciente)){?>
                <tr>
                    
                    <td>
                        <?php foreach($imagensdopaciente as $imgs){?>
                        <img src="<?php echo base_url($imgs->imagem);?>" height="100" width="100" style="margin: 10px; float: left;">
                         <?php }?>
                    </td>
                   
                </tr>
                 <?php }else{?>
                <tr>
                    <td>
                        Nenhuma imagem encontrada para este paciente.
                    </td>
                </tr>
                 <?php }?>
            </table>
           
        </div>
        
    <div style="position: fixed; bottom: 30px; right: 10px; width: 100px;">
          
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript: window.close();">Cancelar</button>
  
        
      </div>        
    </body>
    
</html>

<script type="text/javascript">
$(document).ready(function(){

	//Hide (Collapse) the toggle containers on load
	$(".togglebox").hide(); 

	//Slide up and down on hover
	$("button").click(function(){
		$(this).next(".togglebox").slideToggle("slow");
	});

});
</script>