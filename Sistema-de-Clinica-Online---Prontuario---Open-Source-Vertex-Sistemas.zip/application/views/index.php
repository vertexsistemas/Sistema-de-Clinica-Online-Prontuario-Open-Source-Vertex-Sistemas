<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <title>On Clinica | O seu consultório online de maneira rápida e segura!</title>
    
    
    <link rel="stylesheet" href="<?php echo base_url('public/_css/estilos.css');?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url('public/_css/bootstrap.css');?>" type="text/css" media="screen" />


</head>
<body>

<div id="container">

    
    <div id="containerlogin">
        
        <?php echo form_open('clinica/authentic');?>
        <table border="0">
            <tr>
                <td>
                    <img src="<?php echo base_url('public/_imgs/logoonclinica.png');?>">
                </td>

            </tr>
            <tr>
                <td>
                    <div>
                        <input id="input" type="text" name="email" placeholder="Digite sua identificação" required="required">
                    </div>                    
                </td>
              
            </tr>
            <tr>
                <td>
                    <div>
                       <input id="input" type="password" name="senha" placeholder="Digite sua senha" required="required"> 
                    </div>                    
                </td>  
              
            </tr>
            <tr>
                <td>
                    <div id="esqueciminhasenha">
                        esqueci minha senha!
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="text-align: right;">
                         <button class="btn btn-primary btn-large">Acessar</button>
                    </div>                        
                </td>
            </tr>
        </table>
         <?php echo form_close();?>

        
       
    </div>
    
    
</div>
    <div id="rodape">
        <img src="<?php echo base_url('public/_imgs/logodesenvolvedor.png');?>" height="70" width="180">
    </div>
</body>
</html>