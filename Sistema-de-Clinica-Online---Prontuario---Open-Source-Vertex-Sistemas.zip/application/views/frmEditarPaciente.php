<?php foreach($dadospaciente as $dp);?>
<html>
    <head>
        <meta charset="UTF-8">
        
            <title>On Clinica | O seu consultório online de maneira rápida e segura!</title>


            <link rel="stylesheet" href="<?php echo base_url('public/_css/estilos.css');?>" type="text/css" media="screen" />
            <link rel="stylesheet" href="<?php echo base_url('public/_css/bootstrap.css');?>" type="text/css" media="screen" />
            <script src="<?php echo base_url('public/_js/jquery.js');?>"></script>
            <script src="<?php echo base_url('public/_js/bootstrap.min.js');?>"></script>
            <script src="http://getbootstrap.com/2.3.2/assets/js/holder/holder.js"></script>
            
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/reset.css');?>' />
            <link rel='stylesheet' type='text/css' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/start/jquery-ui.css' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/jquery.weekcalendar.css');?>' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/demo.css');?>' />

            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js'></script>
            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js'></script>

            <script type='text/javascript' src='<?php echo base_url('public/_js/cep.js');?>'></script>

      
    </head>
    
    <body> 
        
<ul class="nav nav-tabs">
  <li class="active"><a href="<?php echo base_url('index.php/clinica/pacientes/'.$dp->idpacientes);?>">Dados pessoais</a></li>
  <li><a href="<?php echo base_url('index.php/clinica/prontuario/'.$dp->idpacientes);?>">Prontuários</a></li>
  <li><a href="<?php echo base_url('index.php/clinica/minhasimagens/'.$dp->idpacientes);?>">Minhas imagens</a></li>
</ul>
        
        
<form id="form1" class="form1" method="post" action="<?php echo base_url('index.php/clinica/salvarpacientes');?>">  
    <input type="hidden" value="<?php echo $dp->idpacientes;?>" name="idpaciente">
    
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel" style="font-weight: bold; font-size: 20px;">Dados do paciente</h4>
      </div>
      
      <div class="modal-body">
        
          <table>
              <tr>
                  <td>
                      Nome do paciente
                  </td>
                  <td>
                      Telefone
                  </td>          
                  <td>
                      Celular
                  </td>      
                  <td>
                     E-mail
                  </td>                  
              </tr>
              <tr>
                  <td>
                     <?php
                                $nomepaciente = array(
                                              'name'        => 'nomepaciente',
                                              'id'          => 'nomepaciente',
                                              'value'       => $dp->nomepacientes,
                                              'maxlength'   => '140',
                                              'size'        => '50',
                                              'style'       => 'width:99%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($nomepaciente);                     
                     ?>
                  </td>
                  <td>
                     <?php
                                $telefone = array(
                                              'name'        => 'telefone',
                                              'id'          => 'telefone',
                                              'value'       => $dp->telefonepacientes,
                                              'maxlength'   => '14',
                                              'size'        => '20',
                                              'style'       => 'width:99%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($telefone);                     
                     ?>                      
                  </td>          
                  <td>
                       <?php
                                $celular = array(
                                              'name'        => 'celular',
                                              'id'          => 'celular',
                                              'value'       => $dp->celularpacientes,
                                              'maxlength'   => '14',
                                              'size'        => '20',
                                              'style'       => 'width:99%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($celular);                     
                     ?>                    
                  </td>      
                  <td>
                         <?php
                                $email = array(
                                              'name'        => 'email',
                                              'id'          => 'email',
                                              'value'       => $dp->emailpacientes,
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:99%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($email);                     
                     ?>                    
                  </td>                  
              </tr>
              <tr>
                  <td>
                     Profissão
                  </td>
                  <td>
                      Cep
                  </td>          
                  <td>
                      Endereço
                  </td>      
                  <td>
                    Nº
                  </td>                  
              </tr> 
              <tr>
                  <td>
                            <?php
                                $profissao = array(
                                              'name'        => 'profissao',
                                              'id'          => 'profissao',
                                              'value'       => $dp->profissao,
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($profissao);                     
                          ?>                      
                  </td>
                  <td>
                          <?php
                                $cep = array(
                                              'name'        => 'cep',
                                              'id'          => 'cep',
                                              'value'       => $dp->cep,
                                              'maxlength'   => '14',
                                              'size'        => '40',
                                              'style'       => 'width:80%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($cep);                     
                          ?>                      
                  </td>          
                  <td>
                           <?php
                                $endereco = array(
                                              'name'        => 'endereco',
                                              'id'          => 'endereco',
                                              'value'       => $dp->endereco,
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($endereco);                     
                          ?>                     
                  </td>      
                  <td>
                            <?php
                                $numero = array(
                                              'name'        => 'numero',
                                              'id'          => 'numero',
                                              'value'       => $dp->numero,
                                              'maxlength'   => '14',
                                              'size'        => '40',
                                              'style'       => 'width:50%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($endereco);                     
                          ?>                    
                  </td>                  
              </tr>   
              <tr>
                  <td>
                     Bairro
                  </td>
                  <td>
                      Cidade
                  </td>          
                  <td>
                      Estado
                  </td>      
                  <td>
                    Data Nascimento
                  </td>                  
              </tr>
              <tr>
                  <td>
                            <?php
                                $bairro = array(
                                              'name'        => 'bairro',
                                              'id'          => 'bairro',
                                              'value'       => $dp->bairro,
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($bairro);                     
                          ?>                       
                  </td>
                  <td>
                            <?php
                                $cidade = array(
                                              'name'        => 'cidade',
                                              'id'          => 'cidade',
                                              'value'       => $dp->cidade,
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($cidade);                     
                          ?>                        
                  </td>          
                  <td>
                             <?php
                                $estado = array(
                                              'name'        => 'estado',
                                              'id'          => 'estado',
                                              'value'       => $dp->estado,
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:50%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($estado);                     
                          ?>                      
                  </td>      
                  <td>
                             <?php
                                $datanasc = array(
                                              'name'        => 'datanasc',
                                              'id'          => 'datanasc',
                                              'value'       => $dp->datanasc,
                                              'maxlength'   => '140',
                                              'size'        => '100',
                                              'style'       => 'width:100%; height:40px;',
                                              'required'    => 'required'
                                            );

                            echo form_input($datanasc);                     
                          ?>                    
                  </td>                  
              </tr>               
          </table>
           
          
      </div>
     
    <div style="position: fixed; bottom: 30px; right: 10px; width: 200px;">
          
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript: window.close();">Cancelar</button>
        <button type="submit" class="btn btn-primary">Editar</button>
        
      </div>
           
</form>           

    </body>
</html>