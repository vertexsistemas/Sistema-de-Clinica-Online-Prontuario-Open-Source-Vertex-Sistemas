<html>
    <head>
        <meta charset="UTF-8">
        
            <title>On Clinica | O seu consultório online de maneira rápida e segura!</title>


            <link rel="stylesheet" href="<?php echo base_url('public/_css/estilos.css');?>" type="text/css" media="screen" />
            <link rel="stylesheet" href="<?php echo base_url('public/_css/bootstrap.css');?>" type="text/css" media="screen" />
            <script src="<?php echo base_url('public/_js/jquery.js');?>"></script>
            <script src="<?php echo base_url('public/_js/bootstrap.min.js');?>"></script>
            <script src="http://getbootstrap.com/2.3.2/assets/js/holder/holder.js"></script>
            
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/reset.css');?>' />
            <link rel='stylesheet' type='text/css' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/start/jquery-ui.css' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/jquery.weekcalendar.css');?>' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/demo.css');?>' />

            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js'></script>
            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js'></script>

            <script type='text/javascript' src='<?php echo base_url('public/_js/cep.js');?>'></script>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
<link href="<?php echo base_url('public/_css/jquery-ui.css');?>"
    rel="stylesheet" type="text/css" />
<script type="text/javascript">
    $(function () {
        $("#dialog").dialog({
            title: "Complete seu cadastro!",
            width: 950 ,
            height:310
        });
    });
</script>
        
      
    </head>
     
    <body>

        <?php if($this->session->userdata('cpfcnpj') == null){?>
<div id="dialog">
   
    <form action="<?php echo base_url('index.php/clinica/salvardados');?>" method="post">
    <table width="800">
        

         <tr>
            
            
            <td>
                <input type="text" value="<?php echo $this->session->userdata('nome');?>"  name="nome" placeholder="Informe seu nome completo"  style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td> 
            <td>
                <input type="text" value="<?php echo $this->session->userdata('telefone');?>" name="telefone"  placeholder="Informe seu telefone" style="width: 150px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
            <td>
                <input type="text" value="<?php echo $this->session->userdata('email');?>" name="email"  placeholder="Informe seu e-mail"  style="width: 200px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
           
            
        </tr> 
        <tr>
            <td>
                <input type="text"  placeholder="Informe seu cpf ou cnpj" name="cpfcnpj" value="<?php echo $this->session->userdata('cpfcnpj');?>" required="required"  style="width: 200px; height: 30px; font-size: 11px; margin: 10px;">
            </td> 
        </tr>        

        <tr>
            
            
            <td>
                <input type="text"  placeholder="Informe o cep" name="cep" value="<?php echo $this->session->userdata('cep');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
            <td>
                <input type="text"  placeholder="Informe o endereço" name="endereco" value="<?php echo $this->session->userdata('endereco');?>" style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
            <td>
                <input type="text"  placeholder="Informe número" name="numero" value="<?php echo $this->session->userdata('numero');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
          
            
        </tr>

        <tr>
            <td>
                <input type="text"  placeholder="Informe o bairro" name="bairro" value="<?php echo $this->session->userdata('bairro');?>" style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>              
        </tr>
        <tr>
            
            
            <td>
                <input type="text"  placeholder="Informe a cidade" name="cidade" value="<?php echo $this->session->userdata('cidade');?>"  style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
            <td>
                <input type="text"  placeholder="Informe o estado" name="estado"  value="<?php echo $this->session->userdata('estado');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>

            <td>
                <input type="submit" value="Salvar" class="btn btn-primary btn-lg">
            </td>            
            
        </tr>        
    </table>
    </form>
    
    
    
    
</div>
        
        <?php }?>
            
        <div class="navbar" style="position: fixed; width: 100%; margin-top: -70px; z-index: 1999;">
                    <a class="brand" href="#"><img src="<?php echo base_url('public/_imgs/onclinicalogointerno.png');?>"></a>
                    <ul class="nav" style="margin-top: 3px;">
                      <?php if($this->session->userdata('cargo') == "secretaria" || $this->session->userdata('cargo')=="administrador"){?>
                     
                            <li><a href="<?php echo base_url('index.php/clinica/agenda/');?>">Agenda</a></li>
                       
                      <?php }else{?>
                      
                            <li><a href="#" style="color:#ccc;">Agenda</a></li>
                      
                      <?php }?>
                      
                      <?php if($this->session->userdata('cargo') == "secretaria" || $this->session->userdata('cargo')=="administrador"){?>
                      
                            <li><a href="<?php echo base_url('index.php/clinica/pacientes/');?>">Pacientes</a></li>
                       
                       <?php }else{?>
                      
                            <li><a href="#" style="color:#ccc;">Pacientes</a></li>
                      
                      <?php }?>
                            
                     <?php if($this->session->userdata('cargo') == "medico" || $this->session->userdata('cargo')=="administrador"){?>
                           
                            <li><a href="<?php echo base_url('index.php/clinica/list_prontuario/');?>">Prontuários</a></li>
                       
                     <?php }else{?>
                     
                           <li><a href="#" style="color:#ccc;">Prontuários</a></li>
                      
                     <?php }?>
                           
                     <?php if($this->session->userdata('cargo') == "medico" || $this->session->userdata('cargo')=="administrador"){?>
                     
                           <li><a href="<?php echo base_url('index.php/clinica/consultacid/');?>">Consulta CID</a></li>
                       
                     <?php }else{?>
                     
                           <li><a href="#" style="color:#ccc;">Consulta CID</a></li>
                      
                     <?php }?>
                     
                     <?php if($this->session->userdata('cargo') == "administrador"){?>
                    
                           <li><a href="<?php echo base_url('index.php/clinica/configuracao/');?>">Configurações</a></li>
                       
                     <?php }else{?>
                     
                            <li><a href="#" style="color:#ccc;">Configurações</a></li>
                      
                     <?php }?>
                    </ul>
                  </div>
 
            
            
        </div>
        
        <div style="margin-top: 70px;" >
            
           
            <table width="100%" class="table table-striped" >
                <tr>
                    <td colspan="5">
                          
                    </td>

                </tr>
                <tr class="table table-condensed">
                    <td style="font-size: 12px; font-weight: bold;">Nome</td>
                    <td style="font-size: 12px; font-weight: bold;">Telefone</td>
                    <td style="font-size: 12px; font-weight: bold;">Celular</td>
                    <td style="font-size: 12px; font-weight: bold;">E-mail</td>
                    <td style="font-size: 12px; font-weight: bold;">Ações</td>
                </tr>
                 <?php if(is_array($agenda)){?>
                <?php foreach($agenda as $a){?>
                <tr class="table table-condensed">
                    <td style="font-size: 12px;"><?php echo $a->nomepacientes;?></td>
                    <td style="font-size: 12px;"><?php echo $a->telefonepacientes;?></td>
                    <td style="font-size: 12px;"><?php echo $a->celularpacientes;?></td>
                    <td style="font-size: 12px;"><?php echo $a->emailpacientes;?></td>    
                    <td>
                        
                        <img style="cursor: pointer;" onclick="javascript:editardados(<?php echo $a->idpacientes;?>,1024,768)" src="<?php echo base_url('public/_imgs/1387237539_edit_property.png');?>" height="20" width="20">
                        
                    </td>    
                </tr>
                <?php }?>
                <?php }else{?>
                <tr>
                    <td colspan="4" style="text-align: center; font-size: 11px;">
                        Nenhum prontuário de consulta agendada foi encontrado para este dia!
                    </td>
                </tr>
               <?php }?>
            </table>
            
        </div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        
 <form id="form1" class="form1" method="post" action="<?php echo base_url('index.php/clinica/salvarpacientes');?>">        
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel" style="font-weight: bold; font-size: 20px;">Novo Paciente</h4>
      </div>
      
      <div class="modal-body">
        
          <table>
              <tr>
                  <td style="font-size: 12px;">
                      Nome do paciente
                  </td>
                  <td style="font-size: 12px;">
                      Telefone
                  </td>          
                  <td style="font-size: 12px;">
                      Celular
                  </td>      
                  <td style="font-size: 12px;">
                     E-mail
                  </td>                  
              </tr>
              <tr>
                  <td>
                     <?php
                                $nomepaciente = array(
                                              'name'        => 'nomepaciente',
                                              'id'          => 'nomepaciente',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '50',
                                              'style'       => 'width:99%',
                                              'required'    => 'required'
                                            );

                            echo form_input($nomepaciente);                     
                     ?>
                  </td>
                  <td>
                     <?php
                                $telefone = array(
                                              'name'        => 'telefone',
                                              'id'          => 'telefone',
                                              'value'       => '',
                                              'maxlength'   => '14',
                                              'size'        => '20',
                                              'style'       => 'width:99%',
                                              'required'    => 'required'
                                            );

                            echo form_input($telefone);                     
                     ?>                      
                  </td>          
                  <td>
                       <?php
                                $celular = array(
                                              'name'        => 'celular',
                                              'id'          => 'celular',
                                              'value'       => '',
                                              'maxlength'   => '14',
                                              'size'        => '20',
                                              'style'       => 'width:99%',
                                              'required'    => 'required'
                                            );

                            echo form_input($celular);                     
                     ?>                    
                  </td>      
                  <td>
                         <?php
                                $email = array(
                                              'name'        => 'email',
                                              'id'          => 'email',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:99%',
                                              'required'    => 'required'
                                            );

                            echo form_input($email);                     
                     ?>                    
                  </td>                  
              </tr>
              <tr>
                  <td style="font-size: 12px;">
                     Profissão
                  </td>
                  <td style="font-size: 12px;">
                      Cep
                  </td>          
                  <td style="font-size: 12px;">
                      Endereço
                  </td>      
                  <td style="font-size: 12px;">
                    Nº
                  </td>                  
              </tr> 
              <tr>
                  <td>
                            <?php
                                $profissao = array(
                                              'name'        => 'profissao',
                                              'id'          => 'profissao',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%',
                                              'required'    => 'required'
                                            );

                            echo form_input($profissao);                     
                          ?>                      
                  </td>
                  <td>
                          <?php
                                $cep = array(
                                              'name'        => 'cep',
                                              'id'          => 'cep',
                                              'value'       => '',
                                              'maxlength'   => '14',
                                              'size'        => '40',
                                              'style'       => 'width:50%',
                                              'required'    => 'required'
                                            );

                            echo form_input($cep);                     
                          ?>                      
                  </td>          
                  <td>
                           <?php
                                $endereco = array(
                                              'name'        => 'endereco',
                                              'id'          => 'endereco',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%',
                                              'required'    => 'required'
                                            );

                            echo form_input($endereco);                     
                          ?>                     
                  </td>      
                  <td>
                            <?php
                                $numero = array(
                                              'name'        => 'numero',
                                              'id'          => 'numero',
                                              'value'       => '',
                                              'maxlength'   => '14',
                                              'size'        => '40',
                                              'style'       => 'width:50%',
                                              'required'    => 'required'
                                            );

                            echo form_input($endereco);                     
                          ?>                    
                  </td>                  
              </tr>   
              <tr>
                  <td style="font-size: 12px;">
                     Bairro
                  </td>
                  <td style="font-size: 12px;">
                      Cidade
                  </td>          
                  <td style="font-size: 12px;">
                      Estado
                  </td>      
                  <td style="font-size: 12px;">
                     Data Nascimento
                  </td>                  
              </tr>
              <tr>
                  <td>
                            <?php
                                $bairro = array(
                                              'name'        => 'bairro',
                                              'id'          => 'bairro',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%',
                                              'required'    => 'required'
                                            );

                            echo form_input($bairro);                     
                          ?>                       
                  </td>
                  <td>
                            <?php
                                $cidade = array(
                                              'name'        => 'cidade',
                                              'id'          => 'cidade',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:98%',
                                              'required'    => 'required'
                                            );

                            echo form_input($cidade);                     
                          ?>                        
                  </td>          
                  <td>
                             <?php
                                $estado = array(
                                              'name'        => 'estado',
                                              'id'          => 'estado',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '40',
                                              'style'       => 'width:50%',
                                              'required'    => 'required'
                                            );

                            echo form_input($estado);                     
                          ?>                      
                  </td>      
                  <td>
                              <?php
                                $datanasc = array(
                                              'name'        => 'datanasc',
                                              'id'          => 'datanasc',
                                              'value'       => '',
                                              'maxlength'   => '140',
                                              'size'        => '100',
                                              'style'       => 'width:100%',
                                              'required'    => 'required',
                                              'type'        => 'date'
                                            );

                            echo form_input($datanasc);                     
                          ?>                   
                  </td>                  
              </tr>               
          </table>
           
          
      </div>
     
      <div class="modal-footer">
          
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary">Cadastrar</button>
        
      </div>
           
</form>           
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->        
       
 <div style="position: fixed; bottom: 0; background-color: #fff; width: 100%; height: 60px; text-align: right; box-shadow: 0 0 5px #888; -moz-box-shadow: 0 0 5px #888; -webkit-box-shadow: 0 0 5px #888;">
    
    <img src="<?php echo base_url('public/_imgs/logodesenvolvedor.png');?>" height="70" width="180">
    
</div>         
    </body>
</html>