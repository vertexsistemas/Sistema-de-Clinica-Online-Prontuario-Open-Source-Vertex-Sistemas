<?php foreach($agenda as $a);?>

<html>
    <head> 
        <meta charset="UTF-8">
          
            <title>On Clinica | O seu consultório online de maneira rápida e segura!</title>


            <link rel="stylesheet" href="<?php echo base_url('public/_css/estilos.css');?>" type="text/css" media="screen" />
            <link rel="stylesheet" href="<?php echo base_url('public/_css/bootstrap.css');?>" type="text/css" media="screen" />
            <script src="<?php echo base_url('public/_js/jquery.js');?>"></script>
            <script src="<?php echo base_url('public/_js/bootstrap.min.js');?>"></script>
            <script src="http://getbootstrap.com/2.3.2/assets/js/holder/holder.js"></script>
            
            
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/reset.css');?>' />
            <link rel='stylesheet' type='text/css' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/start/jquery-ui.css' />


            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js'></script>
            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js'></script>


        <script type='text/javascript' src="<?php echo base_url('public/_js/jquery.autocomplete.js');?>"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('public/_css/jquery.autocomplete.css');?>" />
        <script type="text/javascript">
            var paciente = jQuery.noConflict();
            paciente().ready(function() {
                paciente("#paciente").autocomplete("<?php echo base_url('index.php/clinica/buscaPacientes');?>", {
                    width: 260,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
                
                
            });
           
        </script>   
        
        <script type="text/javascript">
            var medico = jQuery.noConflict();
            medico().ready(function() {
                medico("#medico").autocomplete("<?php echo base_url('index.php/clinica/buscaMedico');?>", {
                    width: 260,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
            });
         
        </script>            
    </head>
    
    <body>
        
<div>
     
  <div class="modal-dialog" >
        
    <div class="modal-content" >
        
  <form id="form1" class="form1" method="post" action="<?php echo base_url('index.php/clinica/editarAgenda');?>">      
 
      <input type="hidden" value="<?php echo $a->idagenda;?>" name="idagenda">
      <div class="modal-body">
        
                 
                 
                  <div class="modal-header">
                   <h4 class="modal-title" id="myModalLabel" style="font-weight: bold; font-size: 20px;">Editar consulta</h4>
                
                  </div>

                  <div class="modal-body">

                      
                      <table>
                          <tr>
                              <td>
                                  Hora da consulta
                              </td>
                              <td>
                                  Data da consulta
                              </td>
                          </tr>
                          <tr>
                              <td>
                                       <select name="horaconsulta" required="required">
                                           <option><?php echo $a->horaconsulta;?></option>
                                           
                                           <option value="07:00">07:00</option>
                                           <option value="07:15">07:15</option>
                                           <option value="07:30">07:30</option>
                                           <option value="07:45">07:45</option>
                                           
                                           
                                           <option value="08:00">08:00</option>
                                           <option value="08:15">08:15</option>
                                           <option value="08:30">08:30</option>
                                           <option value="08:45">08:45</option>
                                           
                                           
                                           <option value="09:00">09:00</option>
                                           <option value="09:15">09:15</option>
                                           <option value="09:30">09:30</option>
                                           <option value="09:45">09:45</option>
                                           
                                           
                                           
                                           <option value="10:00">10:00</option>
                                           <option value="10:15">10:15</option>
                                           <option value="10:30">10:30</option>
                                           <option value="10:45">10:45</option>
                                           
                                           
                                           <option value="11:00">11:00</option>
                                           <option value="11:15">11:15</option>
                                           <option value="11:30">11:30</option>
                                           <option value="11:15">11:45</option>
                                           
                                           
                                           
                                           <option value="12:00">12:00</option>
                                           <option value="12:15">12:15</option>
                                           <option value="12:30">12:30</option>
                                           <option value="12:45">12:45</option>
                                           
                                           
                                           <option value="13:00">13:00</option>
                                           <option value="13:15">13:15</option>
                                           <option value="13:30">13:30</option>
                                           <option value="13:45">13:45</option>
                                           
                                           
                                           <option value="14:00">14:00</option>
                                           <option value="14:15">14:15</option>
                                           <option value="14:30">14:30</option>
                                           <option value="14:45">14:45</option>
                                           
                                           
                                           <option value="15:00">15:00</option>
                                           <option value="15:15">15:15</option>
                                           <option value="15:30">15:30</option>
                                           <option value="15:45">15:45</option>
                                           
                                           
                                           <option value="16:00">16:00</option>
                                           <option value="16:15">16:15</option>
                                           <option value="16:30">16:30</option>
                                           <option value="16:45">16:45</option>
                                           
                                           
                                           <option value="17:00">17:00</option>
                                           <option value="17:15">17:15</option>
                                           <option value="17:30">17:30</option>
                                           <option value="17:45">17:45</option>
                                           
                                           
                                           <option value="18:00">18:00</option>
                                           <option value="18:15">18:15</option>
                                           <option value="18:30">18:30</option>
                                           <option value="18:45">18:45</option>
                                           
                                           
                                           <option value="19:00">19:00</option>
                                           <option value="19:15">19:15</option>
                                           <option value="19:30">19:30</option>
                                           <option value="19:45">19:45</option>
                                           
                                           
                                           <option value="20:00">20:00</option>
                                           <option value="20:15">20:15</option>
                                           <option value="20:30">20:30</option>
                                           <option value="20:45">20:45</option>
                                          
                                       </select>                                  
                              </td>
                              <td>
                                  <input type="date" name="dataconsulta" style="height: 30px; margin-left: 5px;" required="required" value="<?php echo $a->dataconsulta;?>"> 
                              </td>
                          </tr>
                          
                          <tr>
                              <td>Paciente</td>
                              <td>Médico</td>
                          </tr>
                          <tr>
                              <td>
                                  <input type="text" name="paciente" disabled="disabled" id="paciente" value="<?php echo $a->nomepacientes;?>" style="height: 50px; margin-top: 10px;" placeholder="Digite o nome do paciente" required="required" />
                                  
                              </td>
                              <td>
                                  <input type="text" name="medico" disabled="disabled" id="medico" value="<?php echo $a->nome;?>" style="height: 50px; margin-top: 10px;" placeholder="Digite o nome do médico" required="required" />
                                 
                              </td>
                          </tr>
                          <tr>
                              <td colspan="2">Observações</td>
                          </tr>                          
                          <tr>
                              <td colspan="2">
                                  <textarea name="obs"><?php echo $a->obs;?></textarea>
                              </td>
                          </tr>
                      </table>
                      
                      

                  </div>

                  <div class="modal-footer">

                      <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript:window.close();">Cancelar</button>
                    
                    <button type="submit" class="btn btn-primary">Salvar</button>

                 </div>


      </div>
    </form>     
          
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->        
    </body>
</html> 