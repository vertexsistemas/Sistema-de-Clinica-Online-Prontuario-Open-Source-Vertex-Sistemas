<?php foreach($dadospaciente as $dp);?>
<html>
    <head>
        <meta charset="UTF-8">
        
            <title>On Clinica | O seu consultório online de maneira rápida e segura!</title>


            <link rel="stylesheet" href="<?php echo base_url('public/_css/estilos.css');?>" type="text/css" media="screen" />
            <link rel="stylesheet" href="<?php echo base_url('public/_css/bootstrap.css');?>" type="text/css" media="screen" />
            <script src="<?php echo base_url('public/_js/jquery.js');?>"></script>
            <script src="<?php echo base_url('public/ckeditor/ckeditor.js');?>"></script>
            <script src="<?php echo base_url('public/_js/bootstrap.min.js');?>"></script>
            <script src="http://getbootstrap.com/2.3.2/assets/js/holder/holder.js"></script>
            
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/reset.css');?>' />
            <link rel='stylesheet' type='text/css' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/start/jquery-ui.css' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/jquery.weekcalendar.css');?>' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/demo.css');?>' />

            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js'></script>
            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js'></script>

            <script type='text/javascript' src='<?php echo base_url('public/_js/cep.js');?>'></script>

      

 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
<link href="<?php echo base_url('public/_css/jquery-ui.css');?>"
    rel="stylesheet" type="text/css" />
<script type="text/javascript">
    $(function () {
        $("#dialog").dialog({
            title: "Complete seu cadastro!",
            width: 950 ,
            height:310
        });
    });
</script>     
    </head>
    
    <body>

       <?php if($this->session->userdata('cpfcnpj') == null){?>
<div id="dialog">
   
    <form action="<?php echo base_url('index.php/clinica/salvardados');?>" method="post">
    <table width="800">
        

         <tr>
            
            
            <td>
                <input type="text" value="<?php echo $this->session->userdata('nome');?>"  name="nome" placeholder="Informe seu nome completo"  style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td> 
            <td>
                <input type="text" value="<?php echo $this->session->userdata('telefone');?>" name="telefone"  placeholder="Informe seu telefone" style="width: 150px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
            <td>
                <input type="text" value="<?php echo $this->session->userdata('email');?>" name="email"  placeholder="Informe seu e-mail"  style="width: 200px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
           
            
        </tr> 
        <tr>
            <td>
                <input type="text"  placeholder="Informe seu cpf ou cnpj" name="cpfcnpj" value="<?php echo $this->session->userdata('cpfcnpj');?>" required="required"  style="width: 200px; height: 30px; font-size: 11px; margin: 10px;">
            </td> 
        </tr>        

        <tr>
            
            
            <td>
                <input type="text"  placeholder="Informe o cep" name="cep" value="<?php echo $this->session->userdata('cep');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
            <td>
                <input type="text"  placeholder="Informe o endereço" name="endereco" value="<?php echo $this->session->userdata('endereco');?>" style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
            <td>
                <input type="text"  placeholder="Informe número" name="numero" value="<?php echo $this->session->userdata('numero');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
          
            
        </tr>

        <tr>
            <td>
                <input type="text"  placeholder="Informe o bairro" name="bairro" value="<?php echo $this->session->userdata('bairro');?>" style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>              
        </tr>
        <tr>
            
            
            <td>
                <input type="text"  placeholder="Informe a cidade" name="cidade" value="<?php echo $this->session->userdata('cidade');?>"  style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
            <td>
                <input type="text"  placeholder="Informe o estado" name="estado"  value="<?php echo $this->session->userdata('estado');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>

            <td>
                <input type="submit" value="Salvar" class="btn btn-primary btn-lg">
            </td>            
            
        </tr>        
    </table>
    </form>
    
    
    
    
</div>
        
       <?php }?>

            
            <ul class="nav nav-tabs">
              <li><a href="<?php echo base_url('index.php/clinica/editarPaciente/'.$dp->idpacientes);?>">Dados pessoais</a></li>
              <li class="active"><a href="<?php echo base_url('index.php/clinica/prontuario/'.$dp->idpacientes);?>">Prontuários</a></li>
              <li><a href="<?php echo base_url('index.php/clinica/minhasimagens/'.$dp->idpacientes);?>">Minhas imagens</a></li> 
            </ul>
        
        
        <div style="margin: 10px;">
            <table width="100%">
                <tr>
                    <td>
                        <?php echo str_pad($dp->idpacientes, 10, "0", STR_PAD_LEFT);?>
                    </td>
                    <td>
                        <?php echo $dp->nomepacientes;?>
                    </td>
                    <td>
                        <?php echo date('d/m/Y',strtotime($dp->datanasc));?>
                    </td> 
                    <td>
                        <?php $data = explode('-',$dp->datanasc); echo date('Y') - $data[0]." Anos" ?>
                    </td>                     
                </tr>
            </table>
        </div>
        
        <table width="100%">
            <tr>
                <td>
                    <div style="font-size: 25px; font-weight: bold; margin: 10px;">
                        Prontuário de consultas
                    </div>                    
                </td> 

            </tr>
        </table>


        
        <div style="margin: 10px;">
            <table width="100%" class="table table-striped">
                <tr>
                    <td colspan="3">
                          
                        <div style="text-align: right; padding: 10px;"> 
                            <button style=" margin: 10px;" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" id="incluir">Incluir</button>
                            <div class="togglebox">
                              <div class="content">
                                  <h3>
                                      <form action="<?php echo base_url('index.php/clinica/cadastrarHistoricoProntuario/');?>" method="post" enctype="multipart/form-data">
                  
                                          <input type="hidden" name="idclinica" value="<?php echo $this->session->userdata('id');?>">
                                          <input type="hidden" name="idpaciente" value="<?php echo $dp->idpacientes;?>">
                                       <textarea class="ckeditor" name="historico"></textarea>
                                      
                                       <input type="submit" style=" margin: 10px;" class="btn btn-primary btn-lg" id="incluir" value="Salvar">
                                       <input id="fileupload" type="file" name="arquivo[]"  multiple="multiple">
                                      </form>
                                  </h3>
                              </div>
                           </div> 
                    </div>                           
                        
                    </td>
                </tr>
                <?php if(is_array($dadospaciente)){?>
                <?php foreach($dadospaciente as $dph){?>
                <tr>
                    <td>
                        <?php echo $dph->data;?>
                    </td>
                    <td>
                        <?php echo $dph->nomemedico;?>
                    </td>                    
                    <td>
                        <?php echo $dph->historico;?>
                    </td>                    
                </tr>
                <?php }?>
                <?php }?>
            </table>
        </div>
        
    <div style="position: fixed; bottom: 30px; right: 10px; width: 100px;">
          
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript: window.close();">Cancelar</button>
  
        
      </div>        
    </body>
    
</html>

<script type="text/javascript">
$(document).ready(function(){

	//Hide (Collapse) the toggle containers on load
	$(".togglebox").hide(); 

	//Slide up and down on hover
	$("button").click(function(){
		$(this).next(".togglebox").slideToggle("slow");
	});

});
</script>