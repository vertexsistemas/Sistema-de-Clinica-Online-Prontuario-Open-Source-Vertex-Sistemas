
<html>
    <head> 
        <meta charset="UTF-8">
           
            <title>On Clinica | O seu consultório online de maneira rápida e segura!</title>

            <link rel="stylesheet" href="<?php echo base_url('public/_css/estilos.css');?>" type="text/css" media="screen" />
            <link rel="stylesheet" href="<?php echo base_url('public/_css/bootstrap.css');?>" type="text/css" media="screen" />
            <script src="<?php echo base_url('public/_js/jquery.js');?>"></script>
            <script src="<?php echo base_url('public/_js/bootstrap.min.js');?>"></script>
            <script src="http://getbootstrap.com/2.3.2/assets/js/holder/holder.js"></script>
            
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/reset.css');?>' />
            <link rel='stylesheet' type='text/css' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/start/jquery-ui.css' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/jquery.weekcalendar.css');?>' />
            <link rel='stylesheet' type='text/css' href='<?php echo base_url('public/_css/demo.css');?>' />

            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js'></script>
            <script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js'></script>

            <script type='text/javascript' src='<?php echo base_url('public/_js/cep.js');?>'></script>

        <script type='text/javascript' src="<?php echo base_url('public/_js/jquery.autocomplete.js');?>"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('public/_css/jquery.autocomplete.css');?>" />
        <script type="text/javascript">
            var paciente = jQuery.noConflict();
            paciente().ready(function() {
                paciente("#paciente").autocomplete("<?php echo base_url('index.php/clinica/buscaPacientes');?>", {
                    width: 260,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
                
                
            });
           
        </script>   
        
        <script type="text/javascript">
            var medico = jQuery.noConflict();
            medico().ready(function() {
                medico("#medico").autocomplete("<?php echo base_url('index.php/clinica/buscaMedico');?>", {
                    width: 260,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
            });
         
        </script>           

        
        <script type="text/javascript">
            var plano = jQuery.noConflict();
            plano().ready(function() {
                plano("#plano").autocomplete("<?php echo base_url('index.php/clinica/buscaPlano');?>", {
                    width: 260,
                    matchContains: true,
                    //mustMatch: true,
                    //minChars: 0,
                    //multiple: true,
                    //highlight: false,
                    //multipleSeparator: ",",
                    selectFirst: false
                });
            });
         
        </script>
        
        
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>
<link href="<?php echo base_url('public/_css/jquery-ui.css');?>"
    rel="stylesheet" type="text/css" />
<script type="text/javascript">
    $(function () {
        $("#dialog").dialog({
            title: "Complete seu cadastro!",
            width: 950 ,
            height:310
        });
    });
</script>     
    </head>
    
    <body>

       <?php if($this->session->userdata('cpfcnpj') == null){?>
<div id="dialog">
   
    <form action="<?php echo base_url('index.php/clinica/salvardados');?>" method="post">
    <table width="800">
        

         <tr>
            
            
            <td>
                <input type="text" value="<?php echo $this->session->userdata('nome');?>"  name="nome" placeholder="Informe seu nome completo"  style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td> 
            <td>
                <input type="text" value="<?php echo $this->session->userdata('telefone');?>" name="telefone"  placeholder="Informe seu telefone" style="width: 150px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
            <td>
                <input type="text" value="<?php echo $this->session->userdata('email');?>" name="email"  placeholder="Informe seu e-mail"  style="width: 200px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
           
            
        </tr> 
        <tr>
            <td>
                <input type="text"  placeholder="Informe seu cpf ou cnpj" name="cpfcnpj" value="<?php echo $this->session->userdata('cpfcnpj');?>" required="required"  style="width: 200px; height: 30px; font-size: 11px; margin: 10px;">
            </td> 
        </tr>        

        <tr>
            
            
            <td>
                <input type="text"  placeholder="Informe o cep" name="cep" value="<?php echo $this->session->userdata('cep');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
            <td>
                <input type="text"  placeholder="Informe o endereço" name="endereco" value="<?php echo $this->session->userdata('endereco');?>" style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" > 
            </td>
            <td>
                <input type="text"  placeholder="Informe número" name="numero" value="<?php echo $this->session->userdata('numero');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
          
            
        </tr>

        <tr>
            <td>
                <input type="text"  placeholder="Informe o bairro" name="bairro" value="<?php echo $this->session->userdata('bairro');?>" style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>              
        </tr>
        <tr>
            
            
            <td>
                <input type="text"  placeholder="Informe a cidade" name="cidade" value="<?php echo $this->session->userdata('cidade');?>"  style="width: 300px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>
            <td>
                <input type="text"  placeholder="Informe o estado" name="estado"  value="<?php echo $this->session->userdata('estado');?>" style="width: 100px; height: 30px; font-size: 11px; margin: 10px;" required="required" >
            </td>

            <td>
                <input type="submit" value="Salvar" class="btn btn-primary btn-lg">
            </td>            
            
        </tr>        
    </table>
    </form>
    
    
    
    
</div>
        
       <?php }?>            
        <div class="navbar"style="position: absolute; z-index: 1999; width: 100%; margin-top: 0px;" >
                  <div class="navbar-inner">
                    <a class="brand" href="#"><img src="<?php echo base_url('public/_imgs/onclinicalogointerno.png');?>"></a>
                    <ul class="nav" style="margin-top: 3px;">
                      <?php if($this->session->userdata('cargo') == "secretaria" || $this->session->userdata('cargo')=="administrador"){?>
                     
                            <li><a href="<?php echo base_url('index.php/clinica/agenda/');?>">Agenda</a></li>
                       
                      <?php }else{?>
                      
                            <li><a href="#" style="color:#ccc;">Agenda</a></li>
                      
                      <?php }?>
                      
                      <?php if($this->session->userdata('cargo') == "secretaria" || $this->session->userdata('cargo')=="administrador"){?>
                      
                            <li><a href="<?php echo base_url('index.php/clinica/pacientes/');?>">Pacientes</a></li>
                       
                       <?php }else{?>
                      
                            <li><a href="#" style="color:#ccc;">Pacientes</a></li>
                      
                      <?php }?>
                            
                     <?php if($this->session->userdata('cargo') == "medico" || $this->session->userdata('cargo')=="administrador"){?>
                           
                            <li><a href="<?php echo base_url('index.php/clinica/list_prontuario/');?>">Prontuários</a></li>
                       
                     <?php }else{?>
                     
                           <li><a href="#" style="color:#ccc;">Prontuários</a></li>
                      
                     <?php }?>
                           
                     <?php if($this->session->userdata('cargo') == "medico" || $this->session->userdata('cargo')=="administrador"){?>
                     
                           <li><a href="<?php echo base_url('index.php/clinica/consultacid/');?>">Consulta CID</a></li>
                       
                     <?php }else{?>
                     
                           <li><a href="#" style="color:#ccc;">Consulta CID</a></li>
                      
                     <?php }?>
                     
                     <?php if($this->session->userdata('cargo') == "administrador"){?>
                    
                           <li><a href="<?php echo base_url('index.php/clinica/configuracao/');?>">Configurações</a></li>
                       
                     <?php }else{?>
                     
                            <li><a href="#" style="color:#ccc;">Configurações</a></li>
                      
                     <?php }?>
                    </ul>
                  </div>
                </div>

        <div style="position: absolute; top: 50px; z-index: 1981; background-color: #fff; height: 60px; padding-top: 30px;">
            <table width="100%" border="0">
                <tr>
                   
                    <td width="30%" valign="center">
                        <form action='<?php echo base_url('index.php/clinica/agenda/');?>' method="post">
                            
                         <select name="ano" style="margin: 6px;">   
                            <option value='2014'> 2014 </option>
                            <option value='2015'> 2015 </option>
                            <option value='2016'> 2016 </option>
                            <option value='2017'> 2017 </option>
                            <option value='2018'> 2018 </option>
                            <option value='2019'> 2019 </option>
                            <option value='2020'> 2020 </option>
                            <option value='2021'> 2021 </option>
                            <option value='2022'> 2022 </option>
                            <option value='2023'> 2023 </option>
                        </select>                        
                        <button class="btn btn-primary btn-lg" value="01" name="mes">Jan</button>
                        <button class="btn btn-primary btn-lg" value="02" name="mes">Fev</button>
                        <button class="btn btn-primary btn-lg" value="03" name="mes">Mar</button>
                        <button class="btn btn-primary btn-lg" value="04" name="mes">Abr</button>
                        <button class="btn btn-primary btn-lg" value="05" name="mes">Mai</button>
                        <button class="btn btn-primary btn-lg" value="06" name="mes">Jun</button>
                        <button class="btn btn-primary btn-lg" value="07" name="mes">Jul</button>
                        <button class="btn btn-primary btn-lg" value="08" name="mes">Ago</button>
                        <button class="btn btn-primary btn-lg" value="09" name="mes">Set</button>
                        <button class="btn btn-primary btn-lg" value="10" name="mes">Out</button>
                        <button class="btn btn-primary btn-lg" value="11" name="mes">Nov</button>
                        <button class="btn btn-primary btn-lg" value="12" name="mes">Dez</button>
                        
                        </form>
                    </td>

                    <td width="10%">
                        <div style="text-align: right; margin-right: 20px;">
                          <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">Nova consulta</button>
                        </div>                         
                    </td>
                </tr>
            </table>
        </div>
        
        <div style="margin-top: 140px; position: absolute; width: 100%;">
            <table width="100%" class="table table-striped">
                
                
                <tr>
                    <td>Data</td>
                    <td>Hora</td>
                    <td>Paciente</td>
                    <td>Observação</td>
                    <td>Plano</td>
                    <td>Médico</td>
                    <td>Ações</td>
                </tr>
                
                <?php if(is_array($agenda)){?>
                <?php foreach ($agenda as $a){?>
                <tr>
                    <td>
                         <?php echo date('d/m/Y',strtotime($a->dataconsulta));?>
                    </td>
                    <td>
                        <?php echo $a->horaconsulta;?>
                    </td>
                    <td>
                        <?php echo $a->nomepacientes;?>
                    </td>
                    <td>
                        <?php echo $a->obs;?>
                    </td>
                    <td>
                        <?php echo $a->plano;?>
                    </td>                    
                    <td>
                        <?php echo $a->nome;?>
                    </td>
                    <td> 
                       
                        <a href="" onclick="selecionaAgenda('<?php echo $a->idagenda;?>')" title="Editar Consulta">
                        <img src="<?php echo base_url('public/_imgs/1387497498_edit-notes.png');?>" height="20" width="20"/>
                        </a>
                        
                        <a href="<?php echo base_url('index.php/clinica/deletaragenda/'.$a->idagenda);?>" data-confirm="Deseja realmente deletar esta consulta?" title="Deletar Consulta"> 
                        <img src="<?php echo base_url('public/_imgs/1387497505_cancel.png');?>" height="20" width="20"/>
                        </a> 
                    </td>
                </tr>                
                <?php }?>
                <?php }?>
            </table>
        </div> 
             
            
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"  style="margin-top: 90px; z-index: 1980; position: absolute;" >
     
  <div class="modal-dialog" >
      
    <div class="modal-content" >
        
  <form id="form1" class="form1" method="post" action="<?php echo base_url('index.php/clinica/salvarAgenda');?>">      

      
      <div class="modal-body">
        
                 
                 
                  <div class="modal-header">
                      
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                   
                    <h4 class="modal-title" id="myModalLabel" style="font-weight: bold; font-size: 20px;">Nova consulta</h4>
                
                  </div>

                  <div class="modal-body">

                      
                      <table>
                          <tr>
                              <td>
                                  Hora da consulta
                              </td>
                              <td>
                                  Data da consulta
                              </td>
                          </tr>
                          <tr>
                              <td>
                                       <select name="horaconsulta" required="required">
                                           <option>Informe uma hora</option>
                                           
                                           <option value="07:00">07:00</option>
                                           <option value="07:15">07:15</option>
                                           <option value="07:30">07:30</option>
                                           <option value="07:45">07:45</option>
                                           
                                           
                                           <option value="08:00">08:00</option>
                                           <option value="08:15">08:15</option>
                                           <option value="08:30">08:30</option>
                                           <option value="08:45">08:45</option>
                                           
                                           
                                           <option value="09:00">09:00</option>
                                           <option value="09:15">09:15</option>
                                           <option value="09:30">09:30</option>
                                           <option value="09:45">09:45</option>
                                           
                                           
                                           
                                           <option value="10:00">10:00</option>
                                           <option value="10:15">10:15</option>
                                           <option value="10:30">10:30</option>
                                           <option value="10:45">10:45</option>
                                           
                                           
                                           <option value="11:00">11:00</option>
                                           <option value="11:15">11:15</option>
                                           <option value="11:30">11:30</option>
                                           <option value="11:15">11:45</option>
                                           
                                           
                                           
                                           <option value="12:00">12:00</option>
                                           <option value="12:15">12:15</option>
                                           <option value="12:30">12:30</option>
                                           <option value="12:45">12:45</option>
                                           
                                           
                                           <option value="13:00">13:00</option>
                                           <option value="13:15">13:15</option>
                                           <option value="13:30">13:30</option>
                                           <option value="13:45">13:45</option>
                                           
                                           
                                           <option value="14:00">14:00</option>
                                           <option value="14:15">14:15</option>
                                           <option value="14:30">14:30</option>
                                           <option value="14:45">14:45</option>
                                           
                                           
                                           <option value="15:00">15:00</option>
                                           <option value="15:15">15:15</option>
                                           <option value="15:30">15:30</option>
                                           <option value="15:45">15:45</option>
                                           
                                           
                                           <option value="16:00">16:00</option>
                                           <option value="16:15">16:15</option>
                                           <option value="16:30">16:30</option>
                                           <option value="16:45">16:45</option>
                                           
                                           
                                           <option value="17:00">17:00</option>
                                           <option value="17:15">17:15</option>
                                           <option value="17:30">17:30</option>
                                           <option value="17:45">17:45</option>
                                           
                                           
                                           <option value="18:00">18:00</option>
                                           <option value="18:15">18:15</option>
                                           <option value="18:30">18:30</option>
                                           <option value="18:45">18:45</option>
                                           
                                           
                                           <option value="19:00">19:00</option>
                                           <option value="19:15">19:15</option>
                                           <option value="19:30">19:30</option>
                                           <option value="19:45">19:45</option>
                                           
                                           
                                           <option value="20:00">20:00</option>
                                           <option value="20:15">20:15</option>
                                           <option value="20:30">20:30</option>
                                           <option value="20:45">20:45</option>
                                          
                                       </select>                                  
                              </td>
                              <td>
                                    <input type="date" name="dataconsulta" style="height: 30px; margin-left: 5px;" required="required"> 
                              </td>
                          </tr>
                          
                          <tr>
                              <td>Paciente</td>
                              <td>Médico</td>
                          </tr>
                          <tr>
                              <td>
                                  <input type="text" name="paciente" id="paciente" style="height: 50px; margin-top: 10px;" placeholder="Digite o nome do paciente" required="required" />

                              </td>
                              <td>
                                  <input type="text" name="medico" id="medico" style="height: 50px; margin-top: 10px;" placeholder="Digite o nome do médico" required="required" />
                                  
                              </td>
                          </tr>
                          <tr>
                              <td>Observações</td>
                              <td>Plano</td>
                          </tr>                          
                          <tr>
                              <td>
                                  <textarea name="obs"></textarea>
                              </td>
                              <td>
                                  <input type="text" name="plano" id="plano" style="height: 50px; margin-top: 10px; margin-left: 5px;" placeholder="Digite o nome do plano " required="required" > 
                              </td>
                          </tr>
                      </table>
                      
                      

                  </div>

                  <div class="modal-footer">

                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    
                    <button type="submit" class="btn btn-primary">Cadastrar</button>

                 </div>


      </div>
    </form>     
          
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->        







<div style="position: fixed; bottom: 0; background-color: #fff; width: 100%; height: 60px; text-align: right; box-shadow: 0 0 5px #888; -moz-box-shadow: 0 0 5px #888; -webkit-box-shadow: 0 0 5px #888;">
    
    <img src="<?php echo base_url('public/_imgs/logodesenvolvedor.png');?>" height="70" width="180">
    
</div>               
        
    </body>
    
    <script>
function selecionaAgenda(idagenda){
            var width = 600;
            var height = 400;
            var left = 99;
            var top = 99;
 
           window.open('http://www.connect10.com.br/onclinica/index.php/clinica/selecionaAgenda/'+idagenda,'janela', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');
 
}            


var excluir = jQuery.noConflict();
excluir(document).ready(function() {
	excluir('a[data-confirm]').click(function(ev) {
		var href = excluir(this).attr('href');
		if (!excluir('#dataConfirmModal').length) {
			excluir('body').append('<div style="z-index:2000;" id="dataConfirmModal" class="modal" role="dialog" aria-labelledby="dataConfirmLabel" aria-hidden="true"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button><h3 id="dataConfirmLabel"><b>Confirme a solicitação</b></h3></div><div class="modal-body"></div><div class="modal-footer"><button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button><a class="btn btn-primary" id="dataConfirmOK">OK</a></div></div>');
		}  
		excluir'#dataConfirmModal').find('.modal-body').text(excluir(this).attr('data-confirm'));
		excluir('#dataConfirmOK').attr('href', href);
		excluir('#dataConfirmModal').modal({show:true});
		return false;
	});
});
    </script>
    
</html>



