<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class clinica extends CI_Controller {

       public function index()
	{
		$this->load->view('index');
	}
        
        #autenticação de usuários no sistema
        public function authentic(){
            
            $email = addslashes(trim($this->input->post('email')));
            
            $senha = addslashes(trim($this->input->post('senha')));
            
            $this->load->model('mclinica');
            
            $query = $this->mclinica->authentic($email,$senha);
            
            if(is_array($query))
            {
                $data = array('email'     => $email,
                              'id'        => $query[0]->idclinica,
                              'idpai'     => $query[0]->idclinicapai,
                              'nome'      => $query[0]->nome,
                              'cpfcnpj'   => $query[0]->cpfcnpj,
                              'cep'       => $query[0]->cep,
                              'endereco'  => $query[0]->endereco,
                              'bairro'    => $query[0]->bairro,
                              'cidade'    => $query[0]->cidade,   
                              'estado'    => $query[0]->estado,
                              'telefone'  => $query[0]->telefone,
                              'numero'    => $query[0]->numero,
                              'idpai'     => $query[0]->idclinicapai,
                              'cargo'     => $query[0]->profissao,
                              'tempo'     => '3600',
                              'authentic' => true
                             );
                
                
                $this->session->set_userdata($data);
              
                if($query[0]->profissao == "secretaria"){
                    redirect('clinica/agenda');
                }else
                   if($query[0]->profissao == "medico"){
                        redirect('clinica/list_prontuario');
                }else{
                    redirect('clinica/agenda');
                }
                
                
            }else{
 
                echo "<script> window.alert('Usuário ou senha incorreto!'); window.location='".  base_url('index.php')."'</script>";
                
            }
            
        }
        
        public function salvardados()
        {
            
            $nome    = $this->input->post('nome');
            $email   = $this->input->post('email');
            $cpfcnpj = $this->input->post('cpfcnpj');
            $cep     = $this->input->post('cep');
            $endereco= $this->input->post('endereco');
            $bairro  = $this->input->post('bairro');
            $cidade  = $this->input->post('cidade');
            $estado  = $this->input->post('estado');
            $telefone = $this->input->post('telefone');
            $numero   = $this->input->post('numero');

             
             
             
                 $dados = array('email'     => $email   ,
                                'nome'      => $nome    ,
                                'cpfcnpj'   => $cpfcnpj ,
                                'cep'       => $cep     ,
                                'endereco'  => $endereco,
                                'bairro'    => $bairro  ,
                                'cidade'    => $cidade  ,   
                                'estado'    => $estado  ,
                                'telefone'  => $telefone,
                                'numero'    => $numero
    
                             );         
                 
                 $this->mclinica->salvardados($dados,$this->session->userdata('id'));
                 
                 if(true)
                 {
                     echo "<script> window.alert('Dados atualizados com sucesso, por favor faça o login novamente'); window.location='".base_url('index.php')."'</script>";
                     
                 }
        }


        
        
        public function salvarUsuario()
        {
            
            $profissao    = $this->input->post('profissao');
            $email   = $this->input->post('email');
            $senha = $this->input->post('senha');
            
            $this->load->model('mclinica');
            
                  $dados = array('email'       => $email    ,
                                 'senha'       => $senha    ,
                                 'profissao'   => $profissao 
    
                             );            
            $this->mclinica->salvarUsuario($dados); 
            
            
            if(true)
            {
                echo "<script>window.alert('Usuário cadastrado com sucesso!'); window.location='".base_url('index.php/clinica/configuracao')."'</script>";
            }
        }
        

        public function buscaPlano() 
        {
            $nome = $_GET['q'];
            $this->load->model('mclinica');
            $dados = $this->mclinica->buscaPlano($nome); 
            if(count($dados)>0){
                echo $dados[0]->idplanos ."-". $dados[0]->plano;
            }else{
                echo "Não encontramos este plano!";
            }
        }
        
        
        public function buscaMedico() 
        {
            $nome = $_GET['q'];
            $this->load->model('mclinica');
            $dados = $this->mclinica->buscaMedicos($nome,$this->session->userdata('idpai')); 
            if(count($dados)>0){
                echo $dados[0]->idclinica ."-". $dados[0]->nome;
            }else{
                echo "Não encontramos este médico!";
            }
        }
        
 
        public function buscaPacientes() 
        {
            $nome = $_GET['q'];
            $this->load->model('mclinica');
            $dados = $this->mclinica->buscaPaciente($nome); 
            if(count($dados)>0){
                echo $dados[0]->idpacientes ."-". $dados[0]->nomepacientes;
            }else{
                echo "Não encontramos este paciente!";
            }
        }
   
        
        
        public function pacientes(){
            
            $this->load->model('mclinica');
            $dados['pacientes'] = $this->mclinica->pacientes();
            $this->load->view('pacientes',$dados);
            
        }
        
        public function salvarpacientes($idpaciente = null)
        {
          $idpaciente = $this->input->post('idpaciente');
            $nomepaciente = $this->input->post('nomepaciente');
            $telefone     = $this->input->post('telefone');
            $celular      = $this->input->post('celular');
            $email        = $this->input->post('email');
            $profissao    = $this->input->post('profissao');
            $cep          = $this->input->post('cep');
            $endereco     = $this->input->post('endereco');
            $numero       = $this->input->post('numero');
            $bairro       = $this->input->post('bairro');
            $cidade       = $this->input->post('cidade');
            $estado       = $this->input->post('estado');      
            $datanasc     = $this->input->post('datanasc');     
            
            if($idpaciente > 0){
                 $dados = array(
                                "nomepacientes"     => $nomepaciente,
                                "telefonepacientes" => $telefone    ,
                                "celularpacientes"  => $celular     ,
                                "emailpacientes"    => $email       ,
                                "profissao"         => $profissao   ,
                                "cep"               => $cep         ,
                                "endereco"          => $endereco    ,
                                "numero"            => $numero      ,
                                "bairro"            => $bairro      ,
                                "cidade"            => $cidade      ,
                                "estado"            => $estado      ,
                                "datanasc"          => $datanasc    ,
                                "idclinica"         =>  $this->session->userdata('id')
                                
                              );
                
                $this->load->model('mclinica');
                $this->mclinica->salvarPaciente($dados,$idpaciente);               
            }else{
     
                
                 $dados = array(
                                "nomepacientes"     => $nomepaciente,
                                "telefonepacientes" => $telefone    ,
                                "celularpacientes"  => $celular     ,
                                "emailpacientes"    => $email       ,
                                "profissao"         => $profissao   ,
                                "cep"               => $cep         ,
                                "endereco"          => $endereco    ,
                                "numero"            => $numero      ,
                                "bairro"            => $bairro      ,
                                "cidade"            => $cidade      ,
                                "estado"            => $estado      ,
                                "datanasc"          => $datanasc    ,
                                "idclinica"         =>  $this->session->userdata('id')
                                
                              );
                
                $this->load->model('mclinica');
                $this->mclinica->salvarPaciente($dados,null);
                
            }
            
                if(true){
                    redirect('clinica/pacientes');
                }
        }
        
        public function editarPaciente($idpaciente)
        {
            $this->load->model('mclinica');
            $dados['dadospaciente'] = $this->mclinica->pacientes($idpaciente);
            $this->load->view('frmEditarPaciente',$dados);
        }
   
        public function prontuario($idpaciente)
        {
            $this->load->model('mclinica');
            $dados['dadospaciente'] = $this->mclinica->prontuario($idpaciente);
            $this->load->view('prontuario',$dados);
        }
        
        public function minhasimagens($idpaciente)
        {
            $this->load->model('mclinica');
            $dados['dadospaciente']     = $this->mclinica->prontuario($idpaciente);
            $dados['imagensdopaciente'] = $this->mclinica->minhasimagens($idpaciente);
            $this->load->view('diretorioimagens',$dados);
        }        

        public function list_prontuario()
        {
            $this->load->model('mclinica');
            $dados['agenda'] = $this->mclinica->agenda($this->session->userdata('id'),null,null);
            $this->load->view('list-prontuario',$dados); 
        }

        public function agenda()
        {
            $mes = $this->input->post('mes');
            $ano = $this->input->post('ano');
            $this->load->model('mclinica');
            $dados['agenda'] = $this->mclinica->agenda($this->session->userdata('id'),$mes,$ano);
            $this->load->view('system',$dados);
        }
        
        public function salvarAgenda()
        {
           
	$paciente       = explode("-",$this->input->post('paciente'));
        $idpaciente     = $paciente[0];
	//$obs            = $this->input->post('obs');
        $hora           = $this->input->post('horaconsulta');
	$data           = $this->input->post('dataconsulta');
        $obs            = $this->input->post('obs');
        $plano           = $this->input->post('plano');
        $medico         = explode("-",$this->input->post('medico'));
        $idmedico       = $medico[0];

                $dados = array(
                    
                                "dataconsulta"       => $data         ,
                                "horaconsulta"       => $hora         ,
                                "medico"             => $idmedico     ,
                                "obs"                => $obs          ,
                                "paciente"           => $idpaciente   ,
                                "idplano"            => $plano        ,
                                "idclinica"          => $this->session->userdata('idpai') 

                              ); 
                

                $this->load->model('mclinica');
                $this->mclinica->salvarAgenda($dados);
                
                if(true){
                    redirect('clinica/agenda');
                }                
        }
        
        public function selecionaAgenda($idagenda){
           
            $this->load->model('mclinica');
            $dados['agenda'] = $this->mclinica->selecionaAgenda($idagenda);    
            $this->load->view('editarAgenda',$dados);
        }
        
        public function editarAgenda()
        {
        $idagenda       = $this->input->post('idagenda');
	$obs            = $this->input->post('obs');
        $hora           = $this->input->post('horaconsulta');
	$data           = $this->input->post('dataconsulta');
        $obs            = $this->input->post('obs');
        $medico         = $this->input->post('medico');

                $dados = array(
                    
                                "dataconsulta"       => $data         ,
                                "horaconsulta"       => $hora         ,
                                "medico"             => $medico       ,
                                "obs"                => $obs          ,
                                "idclinica"          => $this->session->userdata('id') 
                                
                              ); 
                

                 $this->load->model('mclinica');
                $this->mclinica->editaragenda($dados,$idagenda);
                
                if(true){
                    echo "<script>window.close();</script>";
                }                
        }   
        
        public function deletaragenda($idagenda)
        {
            $this->load->model('mclinica');
            $this->mclinica->deletaragenda($idagenda);
            if(true)
            {
               redirect('clinica/agenda');
            }
        }        
       
        
       public function cadastrarHistoricoProntuario()
       {
           $idpaciente   = $this->input->post('idpaciente');
           $idclinica    = $this->input->post('idclinica');
           $dataconsulta = date('d/m/Y');
           $historico    = $this->input->post('historico');
           
           $dados = array(
                            'idpaciente' => $idpaciente  ,
                            'idclinica'  => $idclinica   ,
                            'data'       => $dataconsulta,
                            'historico'  => $historico
                         );
           $this->load->model('mclinica');
$diretorio = "bibliotecimagens/";


if (!is_dir($diretorio)){ echo "Pasta $diretorio nao existe";} 


else { 


				$arquivo = isset($_FILES['arquivo']) ? $_FILES['arquivo'] : FALSE;
				
					for ($k = 0; $k < count($arquivo['name']); $k++) 
						{
						   $destino = $diretorio.$idpaciente."_".date('dmyhms').$arquivo['name'][$k];
                                                   $dadosimg = array("idpaciente" => $idpaciente, "imagem" => $destino);
						    if (move_uploaded_file($arquivo['tmp_name'][$k], $destino)) {
                                                         
                                                        $this->mclinica->cadastrarHistoricoProntuario($dados);
                                                        $this->mclinica->cadastrarimagens($dadosimg);                                                        
                                                        

                                                    } 
									  
						    else {
                                                        
                                                        echo 
                                                        " <script> "
                                                        .   "window.alert('Ocorreu um problema ao realizar o cadastro da imagem, por favor tente novamente!'); "
                                                        .   "window.location='clinica/prontuario/"."$idpaciente';"
                                                        . "</script>";
                                                         
                                                         }
                                                        
						} 		
                                                        echo "<div align='center' style='text-align='center;'>" 
                                                        . "<img src='".base_url('public/_imgs/1389125985_meanicons_31.png')."' style=' margin-top:200px'>"
                                                        . "<p><a href='".base_url('index.php/clinica/prontuario/'.$idpaciente)."' style='color:#333; text-decoration:none;'>Voltar ao prontuário</a></p>"       
                                                        . "</div>";
				

}            
            
 
       }
       
       public function configuracao()
       {
           $this->load->view('configuracoes');
       }
       
       
       public function pesquisarpaciente()
       {
           $nomepaciente = $this->input->post('pesquisapaciente');
           
            $dados['pacientes'] = $this->mclinica->pacientes(null, $nomepaciente);
            $this->load->view('pacientes',$dados);
            
       }
       
       public function buscaconsultaCID(){
           
           
           $nomecid = $this->input->post('nomecid');
           
           if(strlen($nomecid)>0){
           $this->load->model('mclinica');
           
           $dados['cid'] = $this->mclinica->buscaconsultaCID($nomecid);
           
           $this->load->view('cid',$dados);
           }else{
               echo "<script>alert('Informe algo no campo de pesquisa CID'); location='consultacid'</script>";
           }
           
       }
       
       
       
        public function consultaCID()
        {
            
			$this->load->model('mclinica');
                        //$this->madmin->criaSession();
				
				$maximo = 13;
				
				$inicio = $this->uri->segment(3);
				
				$this->load->library('pagination');
				
				$config['base_url'] = base_url('index.php/clinica/consultaCID/');
				
				$config['total_rows'] = $this->mclinica->contaRegistrosconsultaCID();
			
				$config['uri_segment'] = 3;
				
				$config['per_page'] = $maximo;
				
				$config['first_link'] = 'Primeiro';
				
				$config['cur_tag_open'] = '';
				
				$config['cur_tag_close'] = '';
				
				$config['last_link'] = '&Uacute;ltimo';
				
				$config['next_link'] = 'Pr&oacute;ximo';
				
				$config['prev_link'] = 'Anterior';
				
				$config['full_tag_open'] = '<div>';
				
				$config['full_tag_close'] = '</div>';
				
				$this->pagination->initialize($config);

				$dados['paginacao']  = $this->pagination->create_links();
			
				$dados['cid']    = $this->mclinica->consultaCID($maximo,$inicio);
                                
                                $this->load->view('cid',$dados);

        }       
        
        
        
        public function planos()
        {
            $this->load->model('mclinica');
            $dados['planos'] = $this->mclinica->planos($this->session->userdata('id'));
            $this->load->view('planos',$dados);
        }
        
        
        public function salvarPlano()
        {
             $this->load->model('mclinica');
             
            $nomeplano = $this->input->post('plano');
            
            $dados = array('plano' => $nomeplano);
            
            $this->mclinica->salvarPlano($dados);
            
            if(true)
            {
                redirect('clinica/planos');
            }
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */