<?php

class mclinica extends CI_Model{
    
    
    public function authentic($email, $senha)
    {
        $this->db->where('email',$email);
        $this->db->where('senha',$senha);
        $query = $this->db->get('clinica');
        if($query->num_rows() > 0)
        {
             return $query->result();
            
        }else{
            
            return false;
            
        }
        
    }
    
    public function criaSession()
    {
        $authentic = $this->session->userdata('authenticad');
        if (!isset($authentic) || $authentic != TRUE) 
        {
            redirect('clinica','refresh');
	}        
    }
    
   
    
    public function salvardados($dados,$idclinica)
    {
        $this->db->where('idclinica',$idclinica);
        $query = $this->db->update('clinica',$dados);

    } 
    public function salvarUsuario($dados)
    {
        $this->db->insert('clinica',$dados);

    }   
    
    public function buscaPlano($nome)
    {
        $this->db->like('plano',$nome);
        $query = $this->db->get('planos');
        if($query->num_rows()>0)
        {
            return $query->result();
        }
    }    
    
    public function buscaMedicos($nome,$id)
    {
        $profissao = "medico";
        $this->db->like('nome',$nome);
        $this->db->where('idclinicapai', $id);
        $this->db->where('profissao', $profissao);  
        $query = $this->db->get('clinica');
        if($query->num_rows()>0)
        {
            return $query->result();
        }
    }
    
    
    
    public function buscaPaciente($nome)
    {

        $this->db->like('nomepacientes',$nome);
        $query = $this->db->get('pacientes');
        if($query->num_rows()>0)
        {
            return $query->result();
        }
    }
    
    public function minhasimagens($idpaciente)
    {

        $this->db->where('idpaciente', $idpaciente);
        $query = $this->db->get('diretorioimagens');
        if($query->num_rows()>0)
        {
            return $query->result();
        }
    }    
 
    
    public function cadastrarimagens($dados)
    {
        //print_r($dados);
        $query = $this->db->insert('diretorioimagens',$dados);

    } 
    
    
    public function pacientes($idpaciente=null, $nomepaciente=null)
    {

        if($nomepaciente != null){
         
             
            $this->db->like('nomepacientes',$nomepaciente);
        
        }
        
        if($idpaciente!=null)
         {

             $this->db->where('idpacientes',$idpaciente);

         }

                 
        $query = $this->db->get('pacientes');
        
           if($query->num_rows()>0){

               return $query->result();

           }else{

               return false;

           }                 
             
            

        
    }
    
    
    public function buscaconsultaCID($nomecid)
    {
        $this->db->like('descr',$nomecid);
        $query = $this->db->get('cid10');  
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
        
    }    
    
    public function contaRegistrosconsultaCID(){
            $query = $this->db->count_all('cid10');
            return $query;
    }  
    
    public function consultaCID($maximo, $inicio)
    {
        $this->db->limit($maximo, $inicio);
        $query = $this->db->get('cid10');
        return $query->result();
    }
    
    
    
    public function prontuario($idpaciente=null)
    {
        if($idpaciente!=null)
        {
            $this->db->where('idpacientes',$idpaciente);
        }
        $this->db->join('prontuario','prontuario.idpaciente = pacientes.idpacientes','left');
        $this->db->join('medicos','medicos.idmedico = prontuario.idmedico','left');
        $query = $this->db->get('pacientes');
        if($query->num_rows()>0){
 
            return $query->result();
        
        }else{
        
            return false;
        
        }
        
    }    
    
    
    public function agenda($idclinica=null,$mes=null,$ano=null)
    {
        if( $mes == null and $ano == null ){
            
            $this->db->where('day(dataconsulta)',date('d')); 
            $this->db->where('year(dataconsulta)',date('Y')); 
        
        }else{
             $this->db->where('month(dataconsulta)',$mes); 
            $this->db->where('year(dataconsulta)',$ano);        
            
        }
        
        $this->db->join('pacientes','pacientes.idpacientes = agenda.paciente');
        $this->db->join('clinica','clinica.idclinica = agenda.medico','left');
        $this->db->join('planos','planos.idplanos = agenda.idplano','left');
        if($this->session->userdata('cargo') == "medico"){
            
             $this->db->where('agenda.medico',$idclinica); 
        }
        $this->db->where('agenda.idclinicapai',$this->session->userdata('idpai'));
        $query = $this->db->get('agenda');
        if($query->num_rows()>0){
        
            return $query->result();
        
        }else{
            
            return false;
            
        }
        
    }  
    
    
    public function selecionaAgenda($idagenda)
    {

        $this->db->where('idagenda',$idagenda); 
        $this->db->join('pacientes','pacientes.idpacientes = agenda.paciente');
        $this->db->join('clinica','clinica.idclinica = agenda.medico','left');        
        $query = $this->db->get('agenda');
        if($query->num_rows()>0){
            
            return $query->result();
            
        }else{
            
            return false;
            
        }
        
    }      
    
    
    public function salvarPaciente($dados,$idpaciente){
        
        if($idpaciente > 0)
        {
             $this->db->where('idpacientes',$idpaciente); 
             $query = $this->db->update('pacientes',$dados);
        
        }else{
      
              $query = $this->db->insert('pacientes',$dados);
        
        }
        
       if($query)
       {
           return true;
       }
        
            
        
    }
    
    
    public function salvarAgenda($dados)
    {
        $query = $this->db->insert('agenda',$dados);
        
       if($query)
       {
           return true;
       }       
    }
    
    
    public function editaragenda($dados,$idagenda)
    {
        $this->db->where('idagenda',$idagenda);
        $query = $this->db->update('agenda',$dados);
        
       if($query)
       {
           return true;
       }       
    }    
    
    
    public function deletaragenda($idagenda)
    {
        $this->db->where('idagenda',$idagenda);
        $query = $this->db->delete('agenda');
        
       if($query)
       {
           return true;
       }       
    }    
    
    
    public function cadastrarHistoricoProntuario($dados)
    {
        $query = $this->db->insert('prontuario',$dados);
        
       if($query)
       {
           return true;
       }          
    }
    
    
    public function planos($idclinica)
    {
        $this->db->where('idclinica',$idclinica);
        $query = $this->db->get('planos');
        if($query->num_rows()>0){

                   return $query->result();

               }else{

                   return false;

               }
    }
    
    public function salvarPlano($dados)
    {
       $query =  $this->db->insert('planos',$dados);
        
       if($query)
       {
           return true;
       }
    }
    
}