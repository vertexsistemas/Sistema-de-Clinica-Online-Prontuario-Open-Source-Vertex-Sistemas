var cep = jQuery.noConflict();
cep(document).ready( function() {
   /* Executa a requisição quando o campo CEP perder o foco */
   cep('#cep').blur(function(){
           /* Configura a requisição AJAX */
           cep.ajax({
                url : 'http://www.connect10.com.br/onclinica/public/_js/consultar_cep.php', /* URL que será chamada */ 
                type : 'POST', /* Tipo da requisição */ 
                data: 'cep=' + $('#cep').val(), /* dado que será enviado via POST */
                dataType: 'json', /* Tipo de transmissão */
                success: function(data){
                    if(data.sucesso == 1){
                        cep('#endereco').val(data.endereco);
                        cep('#bairro').val(data.bairro);
                        cep('#cidade').val(data.cidade);
                        cep('#estado').val(data.estado);
 
                        cep('#numero').focus();
                    }
                }
           });   
   return false;    
   })
});


function editardados(idpaciente,w,h){
    
    var newW = w + 100;
    var newH = h + 100;
    var left = (screen.width-newW)/2;
    var top = (screen.height-newH)/2;
    var newwindow = window.open('http://www.connect10.com.br/onclinica/index.php/clinica/editarPaciente/'+idpaciente, 'Editar Paciente', 'width='+newW+',height='+newH+',left='+left+',top='+top);
    newwindow.resizeTo(newW, newH);

    //posiciona o popup no centro da tela
    newwindow.moveTo(left, top);
    newwindow.focus();
    return false;
    
//    
//  var width = 980;
//  var height = 600 ;
//  var left = 300;
//  var top = 450;
// 
//  window.open('http://www.connect10.com.br/onclinica/index.php/clinica/editarPaciente/'+idpaciente,'Editar Pacientes', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');
// 
    
}
