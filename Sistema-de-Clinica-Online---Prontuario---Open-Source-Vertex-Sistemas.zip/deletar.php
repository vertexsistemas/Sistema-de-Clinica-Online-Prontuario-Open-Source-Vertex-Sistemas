<?php
$action = $_REQUEST['action'];

if (!$link = mysql_connect('localhost', 'connect1_onclini', 'con24794962*')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('connect1_onclinica', $link)) {
    echo 'Could not select database';
    exit;
}

if($action == 'save')
{

$id= $_GET['id'];

$sql = "DELETE from meeting_rooms_calendar where id=".$id."";
$res = mysql_query($sql) OR DIE ('ERRO');
}
?>