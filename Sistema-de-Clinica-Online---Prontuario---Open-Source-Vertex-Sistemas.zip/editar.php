<?php
$action = $_REQUEST['action'];

if (!$link = mysql_connect('localhost', 'connect1_onclini', 'con24794962*')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('connect1_onclinica', $link)) {
    echo 'Could not select database';
    exit;
}

if($action == 'save')
{
$start_time = (int)$_REQUEST['start'];
$start_time = $start_time;
$end_time = (int)$_REQUEST['end'];
$end_time = $end_time;
$start = date('c',$start_time);
$end = date('c',$end_time);
$id= $_GET['id'];
$title= $_GET['title'];
$body= $_GET['body'];


$sql = "UPDATE meeting_rooms_calendar SET title = '$title',body='$body', start='$start',end='$end' where id='$id'";
$res = mysql_query($sql);
echo  mysql_errno($link). "-" .mysql_error ( $link_identifier);


}
?>